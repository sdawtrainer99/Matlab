function varargout = Opciones(varargin)
% OPCIONES MATLAB code for Opciones.fig
%      OPCIONES, by itself, creates a new OPCIONES or raises the existing
%      singleton*.
%
%      H = OPCIONES returns the handle to a new OPCIONES or the handle to
%      the existing singleton*.
%
%      OPCIONES('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in OPCIONES.M with the given input arguments.
%
%      OPCIONES('Property','Value',...) creates a new OPCIONES or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Opciones_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Opciones_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Opciones

% Last Modified by GUIDE v2.5 09-Dec-2016 12:42:22

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Opciones_OpeningFcn, ...
                   'gui_OutputFcn',  @Opciones_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Opciones is made visible.
function Opciones_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Opciones (see VARARGIN)

% Choose default command line output for Opciones
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Opciones wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Opciones_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
contenido=get(hOject,'String');
a=get(hObject,'Value');
texto=contenido(a);
switch cell2mat(texto)
    case 'Inversa'
    set(handles.textito,'String','es la primera opcion')

    case 'Determinante'
    set(handles.textito,'String','es la segunda opcion')
    case 'Gauss' 
        set(handles.textito,'String','es la tercera opcion')

    %set(handles.textito,'String',texto)


% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function textito_CreateFcn(hObject, eventdata, handles)
% hObject    handle to textito (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
