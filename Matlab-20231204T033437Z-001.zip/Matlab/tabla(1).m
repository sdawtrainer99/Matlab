function varargout = tabla(varargin)
% TABLA MATLAB code for tabla.fig
%      TABLA, by itself, creates a new TABLA or raises the existing
%      singleton*.
%
%      H = TABLA returns the handle to a new TABLA or the handle to
%      the existing singleton*.
%
%      TABLA('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TABLA.M with the given input arguments.
%
%      TABLA('Property','Value',...) creates a new TABLA or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before tabla_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to tabla_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help tabla

% Last Modified by GUIDE v2.5 13-Dec-2016 13:13:37

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @tabla_OpeningFcn, ...
                   'gui_OutputFcn',  @tabla_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before tabla is made visible.
function tabla_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to tabla (see VARARGIN)

% Choose default command line output for tabla
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes tabla wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = tabla_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in pop.
function pop_Callback(hObject, eventdata, handles)
% hObject    handle to pop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns pop contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pop


% --- Executes during object creation, after setting all properties.
function pop_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in insertar.
function insertar_Callback(hObject, eventdata, handles)
Nombres={'Lizbeth' 'Julio' 'Jhefereson' 'Andr�s' 'Jack' };
Notas={20 12 8 21 18};
datos=[Nombres' Notas'];
set(handles.tabla1,'data',datos); 

% --- Executes on button press in guardar.
function guardar_Callback(hObject, eventdata, handles)
c=get(handles.tabla1,'data');
n=size(c,1);
archivo=fopen('datos.dat','w');
for i=1:n
    fprintf(archivo,'%s %s \n' ,c{i,:});
end
fclose(archivo);
% --- Executes when entered data in editable cell(s) in tabla1.
function tabla1_CellEditCallback(hObject, eventdata, handles)
% hObject    handle to tabla1 (see GCBO)
% eventdata  structure with the following fields (see UITABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in cargar.
function cargar_Callback(hObject, eventdata, handles)
A=importdata('datos.dat');
Nombres=a.textdata;
Nota=a.data;
Nota=num2cell(Nota);
datos=[Nombre Nota];
set (handles.tabla1,'data',datos);


% --- Executes on button press in borrar.
function borrar_Callback(hObject, eventdata, handles)
% hObject    handle to borrar (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
